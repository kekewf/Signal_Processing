Imports System

Namespace ArryLoad
	Public Interface ISpeechRecorder
		Sub SetFileName(fileName As String)

		Sub StartRec()

		Sub StopRec()
	End Interface
End Namespace
